#include <unistd.h>
#include <stdio.h>
#include "gpio.h"
#include "uart.h"

#define GPIO_BASE 0xFE200000

int main()
{

void printf(char *str) {
	uart_puts(str);
}

		while(1)
		{
			printf("Hello world!");
		}

    printf("Program is terminating");
    return 0;
}
