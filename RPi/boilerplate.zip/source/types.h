typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned long int uint64_t;
typedef uint64_t uintptr_t;
